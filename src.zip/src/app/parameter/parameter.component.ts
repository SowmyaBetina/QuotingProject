import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ParameterService } from 'src/services/parameter.service';
@Component({
  selector: 'app-parameter',
  templateUrl: './parameter.component.html',
  styleUrls: ['./parameter.component.css']
})
export class ParameterComponent {


}
