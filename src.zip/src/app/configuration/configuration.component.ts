import { Component } from '@angular/core';
import { ProductService } from 'src/services/product.service';
import { FeatureService } from 'src/services/feature.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.css']
})
export class ConfigurationComponent {
  products: string[] = []; 
  selectedName: string = '';
  selectedProductDetails: any = null;
  productName: string = '';
  constructor(private productService: ProductService, private featureService: FeatureService, private router: Router) {}

  ngOnInit(): void {
    this.productService.getProductNames().subscribe((data: string[]) => {
      this.products = data;
    });
  }
  enableFeatures(productName: string): void {
    if (productName) {
      
      this.featureService.getProductDetails(productName).subscribe((data: any) => {
        this.selectedProductDetails = data;
      });
    }
  }
  viewFeatures(productName: string) {
    this.router.navigate(['/features', productName]);
  }

  

}
