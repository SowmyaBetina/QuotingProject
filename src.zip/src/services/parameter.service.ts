import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ParameterService {
  private baseUrl = 'http://localhost:8080/quotes'; 

  constructor(private http: HttpClient) {}

  getParametersForFeature(name: string): Observable<any> {
    console.log(name,"gg");
    
    const url = `${this.baseUrl}/parameters/${name}`; 
    return this.http.get(url);
  }
  
}
